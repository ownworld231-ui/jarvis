package com.example.jarvis

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/** Downloads the free offline Vosk speech model (~40 MB) once, for the "Hey Jarvis" wake word. */
object ModelStore {
    private const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
    private const val NAME = "vosk-model-small-en-us-0.15"

    fun dir(ctx: Context) = File(ctx.filesDir, NAME)
    fun ready(ctx: Context) = File(dir(ctx), "am").exists()

    fun download(ctx: Context, progress: (String) -> Unit) {
        val zip = File(ctx.cacheDir, "model.zip")
        val c = URL(MODEL_URL).openConnection() as HttpURLConnection
        c.connectTimeout = 20000; c.readTimeout = 30000
        val total = c.contentLength
        var lastPct = -10
        c.inputStream.use { input ->
            zip.outputStream().use { out ->
                val buf = ByteArray(65536)
                var done = 0L
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n); done += n
                    if (total > 0) {
                        val pct = (done * 100 / total).toInt()
                        if (pct >= lastPct + 10) { lastPct = pct; progress("Downloading voice model $pct%") }
                    }
                }
            }
        }
        val base = ctx.filesDir.canonicalPath
        ZipInputStream(zip.inputStream()).use { z ->
            var e = z.nextEntry
            while (e != null) {
                val f = File(ctx.filesDir, e.name)
                if (!f.canonicalPath.startsWith(base)) throw SecurityException("bad zip entry")
                if (e.isDirectory) f.mkdirs() else {
                    f.parentFile?.mkdirs()
                    f.outputStream().use { z.copyTo(it) }
                }
                e = z.nextEntry
            }
        }
        zip.delete()
    }
}
