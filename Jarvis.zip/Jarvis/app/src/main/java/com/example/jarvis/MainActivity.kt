package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.FileProvider
import java.io.File

class MainActivity : Activity() {
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var settingsBox: LinearLayout
    private val fields = mutableMapOf<String, EditText>()
    private val prefs by lazy { getSharedPreferences("jarvis", MODE_PRIVATE) }
    private var pendingAfterPermission: (() -> Unit)? = null

    private fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label; setOnClickListener { onClick() }
    }

    private fun field(key: String, hint: String, secret: Boolean = false) = EditText(this).apply {
        this.hint = hint
        setHintTextColor(Color.GRAY); setTextColor(Color.WHITE)
        setText(prefs.getString(key, ""))
        if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        fields[key] = this
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0A0F1C"))
            setPadding(32, 72, 32, 24)
        }
        root.addView(TextView(this).apply {
            text = "J.A.R.V.I.S."; textSize = 24f; setTextColor(Color.parseColor("#7DF9FF"))
        })

        settingsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        settingsBox.addView(field("key", "Gemini API key (free: aistudio.google.com)", true))
        settingsBox.addView(field("city", "Your city (for weather briefing)"))
        settingsBox.addView(field("ha_url", "Home Assistant URL (optional, e.g. http://192.168.1.5:8123)"))
        settingsBox.addView(field("ha_token", "Home Assistant long-lived token (optional)", true))
        settingsBox.addView(btn("Enable notification reading") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        settingsBox.addView(btn("Enable screen control") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(btn("Settings") {
            settingsBox.visibility = if (settingsBox.visibility == View.GONE) View.VISIBLE else View.GONE
        })
        root.addView(settingsBox)

        logView = TextView(this).apply { setTextColor(Color.parseColor("#7DF9FF")); textSize = 16f }
        scroll = ScrollView(this).apply { addView(logView) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val lp = LinearLayout.LayoutParams(0, -2, 1f)
        row.addView(btn("START") { withPermissions { startJarvis(JarvisService.ACT_START) } }, lp)
        row.addView(btn("TALK") { withPermissions { startJarvis(JarvisService.ACT_TALK) } }, lp)
        row.addView(btn("LOOK") { withPermissions { takePhoto() } }, lp)
        row.addView(btn("STOP") { startJarvis(JarvisService.ACT_STOP) }, lp)
        root.addView(row)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        logView.text = JarvisService.buffer.toString()
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        JarvisService.log = { m -> runOnUiThread { logView.append("\n$m\n"); scroll.post { scroll.fullScroll(View.FOCUS_DOWN) } } }
        JarvisService.onLook = { runOnUiThread { takePhoto() } }
    }

    override fun onPause() {
        saveSettings()
        JarvisService.log = null
        JarvisService.onLook = null
        super.onPause()
    }

    private fun saveSettings() {
        val e = prefs.edit()
        fields.forEach { (k, v) -> e.putString(k, v.text.toString().trim()) }
        e.apply()
    }

    private fun startJarvis(action: String) {
        saveSettings()
        startForegroundService(Intent(this, JarvisService::class.java).setAction(action))
    }

    private fun withPermissions(then: () -> Unit) {
        val needed = listOf(Manifest.permission.RECORD_AUDIO, "android.permission.POST_NOTIFICATIONS",
            Manifest.permission.READ_CALENDAR)
            .filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (needed.isEmpty()) then() else {
            pendingAfterPermission = then
            requestPermissions(needed.toTypedArray(), 1)
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            pendingAfterPermission?.invoke()
        }
        pendingAfterPermission = null
    }

    private fun takePhoto() {
        val f = File(cacheDir, "look.jpg")
        val uri = FileProvider.getUriForFile(this, "$packageName.fp", f)
        startActivityForResult(Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            .putExtra(MediaStore.EXTRA_OUTPUT, uri)
            .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION), 7)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 7 && res == RESULT_OK) {
            saveSettings()
            startForegroundService(Intent(this, JarvisService::class.java)
                .setAction(JarvisService.ACT_VISION)
                .putExtra("path", File(cacheDir, "look.jpg").absolutePath)
                .putExtra("prompt", JarvisService.lookQuestion))
        }
    }
}
