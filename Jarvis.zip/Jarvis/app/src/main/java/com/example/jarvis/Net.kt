package com.example.jarvis

import java.net.HttpURLConnection
import java.net.URL

object Net {
    fun get(url: String, headers: Map<String, String> = emptyMap(), timeout: Int = 15000): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = timeout; c.readTimeout = timeout
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    fun post(url: String, json: String, headers: Map<String, String> = emptyMap(), timeout: Int = 30000): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true
        c.connectTimeout = timeout; c.readTimeout = timeout
        c.setRequestProperty("Content-Type", "application/json")
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.outputStream.use { it.write(json.toByteArray()) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        return code to (stream?.bufferedReader()?.use { it.readText() } ?: "")
    }
}
