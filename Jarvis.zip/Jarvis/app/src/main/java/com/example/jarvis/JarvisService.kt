package com.example.jarvis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import java.io.ByteArrayOutputStream
import java.util.Locale

/** The always-on brain: "Hey Jarvis" wake word -> listen -> think -> speak/act. */
class JarvisService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val ACT_START = "start"
        const val ACT_STOP = "stop"
        const val ACT_TALK = "talk"
        const val ACT_VISION = "vision"
        var log: ((String) -> Unit)? = null
        var onLook: (() -> Unit)? = null
        var lookQuestion = "What is in this image? Answer briefly."
        val buffer = StringBuilder()
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private var wake: SpeechService? = null
    private var voskModel: Model? = null
    private var wakeEnabled = false
    private var busy = false
    private var pending = 0   // utterances still being spoken
    private var working = 0   // background jobs in flight
    private var haEntities = ""
    private val prefs by lazy { getSharedPreferences("jarvis", MODE_PRIVATE) }

    private fun facts(): List<String> = prefs.getStringSet("facts", emptySet())!!.toList()
    private val brain = Brain({ facts() }, { extraContext() })
    private val actions by lazy {
        Actions(this) { f -> prefs.edit().putStringSet("facts", facts().toSet() + f).apply() }
    }

    // ---------- lifecycle ----------
    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        tts = TextToSpeech(this, this)
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { r ->
            r.setRecognitionListener(object : android.speech.RecognitionListener {
                override fun onResults(results: Bundle?) {
                    val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrBlank()) maybeResume() else handle(t)
                }
                override fun onError(error: Int) { maybeResume() }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
        }
    }

    override fun onInit(status: Int) {
        tts.language = Locale.getDefault()
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { spoken() }
            @Deprecated("Deprecated in Java") override fun onError(id: String?) { spoken() }
            override fun onStop(id: String?, interrupted: Boolean) { spoken() }
        })
        ttsReady = true
    }

    private fun spoken() = main.post { pending = maxOf(0, pending - 1); maybeResume() }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("Jarvis is online")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)

        when (intent?.action) {
            ACT_STOP -> { stopWake(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
            ACT_TALK -> if (!busy) { busy = true; stopWake(); listenCommand() }
            ACT_VISION -> handleVision(intent.getStringExtra("path") ?: "", intent.getStringExtra("prompt") ?: lookQuestion)
            else -> { loadHomeAssistant(); initWake(); emit("Jarvis online. Say \"Hey Jarvis\".") }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopWake(); recognizer?.destroy(); tts.shutdown(); super.onDestroy()
    }

    private fun emit(msg: String) {
        buffer.append("\n").append(msg).append("\n")
        if (buffer.length > 8000) buffer.delete(0, 2000)
        log?.invoke(msg)
    }

    // ---------- wake word (free, offline, Vosk) ----------
    private fun initWake() {
        if (voskModel != null) { startWake(); return }
        if (!ModelStore.ready(this)) {
            Thread {
                try { ModelStore.download(this) { m -> main.post { emit(m) } } }
                catch (e: Exception) {
                    main.post { emit("Voice model download failed (${e.message}). Tap TALK still works.") }
                    return@Thread
                }
                main.post { loadModel() }
            }.start()
        } else loadModel()
    }

    private fun loadModel() {
        Thread {
            try {
                val m = Model(ModelStore.dir(this).absolutePath)
                main.post { voskModel = m; wakeEnabled = true; startWake(); emit("Wake word ready.") }
            } catch (e: Exception) { main.post { emit("Wake word unavailable: ${e.message}") } }
        }.start()
    }

    private fun startWake() {
        val m = voskModel ?: return
        if (!wakeEnabled || busy || wake != null) return
        try {
            val rec = Recognizer(m, 16000f, "[\"hey jarvis\", \"jarvis\", \"[unk]\"]")
            val svc = SpeechService(rec, 16000f)
            svc.startListening(object : org.vosk.android.RecognitionListener {
                override fun onPartialResult(h: String?) { if (h != null && h.contains("jarvis")) main.post { onWake() } }
                override fun onResult(h: String?) { if (h != null && h.contains("jarvis")) main.post { onWake() } }
                override fun onFinalResult(h: String?) {}
                override fun onError(e: Exception?) {}
                override fun onTimeout() {}
            })
            wake = svc
        } catch (e: Exception) { emit("Microphone busy: ${e.message}") }
    }

    private fun stopWake() { wake?.stop(); wake?.shutdown(); wake = null }

    private fun onWake() {
        if (busy) return
        busy = true
        stopWake()
        try { ToneGenerator(AudioManager.STREAM_MUSIC, 80).startTone(ToneGenerator.TONE_PROP_BEEP, 120) } catch (_: Exception) {}
        main.postDelayed({ listenCommand() }, 350)
    }

    private fun listenCommand() {
        tts.stop(); pending = 0
        recognizer?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM))
    }

    /** Go back to waiting for "Hey Jarvis" once nothing is being spoken or processed. */
    private fun maybeResume() {
        if (pending == 0 && working == 0) { busy = false; startWake() }
    }

    // ---------- thinking ----------
    private fun speak(text: String) {
        emit("JARVIS: $text")
        if (!ttsReady) return
        pending++
        tts.speak(text, TextToSpeech.QUEUE_ADD, null, "u" + System.nanoTime())
    }

    private fun handle(text: String, image: ByteArray? = null) {
        emit("YOU: $text")
        val key = prefs.getString("key", "")!!
        if (key.isEmpty()) { speak("Please enter your Gemini API key first."); maybeResume(); return }
        working++
        Thread {
            val res = try { brain.ask(text, key, image) } catch (e: Exception) {
                JSONObject().put("say", "I can't reach my systems right now.").put("action", "none")
            }
            main.post { reply(res, key); working--; maybeResume() }
        }.start()
    }

    private fun reply(res: JSONObject, key: String) {
        val say = res.optString("say")
        if (say.isNotBlank()) speak(say)
        val act = res.optString("action", "none")
        if (act.isBlank() || act == "none") return
        runAction(act, res.optJSONObject("args") ?: JSONObject(), key)
    }

    /** Fetch data in the background, then let the brain summarize it aloud. */
    private fun data(key: String, label: String, supplier: () -> String) {
        working++
        Thread {
            val d = try { supplier() } catch (e: Exception) { "error: ${e.message}" }
            val res = try {
                brain.ask("[DATA: $label]\n$d\nSummarize this naturally for the user in speech. Action none.", key)
            } catch (e: Exception) { JSONObject().put("say", "I couldn't process that.") }
            main.post { speak(res.optString("say")); working--; maybeResume() }
        }.start()
    }

    private fun runAction(act: String, a: JSONObject, key: String) {
        when (act) {
            "briefing" -> data(key, "morning briefing") { Briefing.build(this, prefs.getString("city", "")!!) }
            "read_notifications" -> data(key, "recent notifications") {
                JarvisNotifications.recent.toList().takeLast(8).joinToString("\n")
                    .ifEmpty { "No notifications captured. Notification access may be off." }
            }
            "read_screen" -> data(key, "screen text") {
                JarvisAccessibility.instance?.readScreen() ?: "Accessibility access is off."
            }
            "look" -> {
                lookQuestion = a.optString("question", "What is in this image? Answer briefly.")
                val cb = onLook
                if (cb != null) cb() else speak("Please open my app so I can use the camera, sir.")
            }
            "home" -> {
                val url = prefs.getString("ha_url", "")!!
                val tok = prefs.getString("ha_token", "")!!
                if (url.isEmpty()) { speak("Home Assistant isn't set up yet."); return }
                working++
                Thread {
                    val ok = try {
                        HomeAssistant.call(url, tok, a.optString("domain"), a.optString("service"), a.optString("entity_id"))
                    } catch (e: Exception) { false }
                    main.post { if (!ok) speak("That didn't work, sir."); working--; maybeResume() }
                }.start()
            }
            "screen" -> {
                val acc = JarvisAccessibility.instance
                if (acc == null) { speak("Please enable my screen control access first."); return }
                val ok = when (a.optString("do")) {
                    "click" -> acc.click(a.optString("text"))
                    "scroll_down" -> acc.scroll(true)
                    "scroll_up" -> acc.scroll(false)
                    "type" -> acc.typeText(a.optString("text"))
                    else -> acc.global(a.optString("do"))
                }
                if (!ok) speak("I couldn't do that on screen.")
            }
            else -> try { actions.run(act, a) } catch (e: Exception) { speak("I couldn't do that, sir.") }
        }
    }

    // ---------- vision ----------
    private fun handleVision(path: String, prompt: String) {
        val bmp = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = 2 })
        if (bmp == null) { speak("I couldn't read the photo."); return }
        val scale = 1024f / maxOf(bmp.width, bmp.height)
        val b2 = if (scale < 1f)
            Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true) else bmp
        val out = ByteArrayOutputStream()
        b2.compress(Bitmap.CompressFormat.JPEG, 80, out)
        busy = true; stopWake()
        handle(prompt, out.toByteArray())
    }

    // ---------- context & smart home ----------
    private fun extraContext(): String {
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val battery = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        return "Battery: $battery%\nSmart-home entities (for action home):\n" + haEntities.ifEmpty { "(not configured)" }
    }

    private fun loadHomeAssistant() {
        val url = prefs.getString("ha_url", "")!!
        val tok = prefs.getString("ha_token", "")!!
        if (url.isEmpty() || tok.isEmpty()) return
        Thread { try { haEntities = HomeAssistant.entities(url, tok) } catch (_: Exception) {} }.start()
    }
}
