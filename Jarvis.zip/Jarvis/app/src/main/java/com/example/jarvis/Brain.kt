package com.example.jarvis

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Free LLM brain: Google Gemini free tier (key from aistudio.google.com). Supports text + images. */
class Brain(private val memory: () -> List<String>, private val extra: () -> String) {
    private val model = "gemini-2.5-flash" // change if Google renames it
    private val history = mutableListOf<Pair<String, String>>()

    private fun systemPrompt(): String {
        val now = SimpleDateFormat("EEEE, d MMM yyyy HH:mm", Locale.getDefault()).format(Date())
        val facts = memory().joinToString("\n") { "- $it" }.ifEmpty { "(none yet)" }
        return """
You are JARVIS, a witty, concise, loyal voice assistant on the user's Android phone. Address the user as "sir" or "ma'am" sparingly. Keep spoken replies under 2 sentences unless summarizing data.
Current time: $now
Known facts about the user:
$facts
Device context:
${extra()}

Reply ONLY with JSON: {"say":"<spoken reply>","action":"<name or none>","args":{...}}
Actions:
- open_app {name}
- dial {number}
- sms {number, text}   (opens a draft)
- set_alarm {hour(0-23), minute, label}
- set_timer {seconds, label}
- flashlight {on(true/false)}
- web_search {query}
- play_music {query}
- navigate {destination}
- remember {fact}   (save a lasting fact about the user)
- home {domain, service, entity_id}   (smart home, e.g. light/turn_on; use entity ids listed above)
- briefing   (weather + calendar + news; say a short ack first)
- read_notifications   (read the user's recent notifications)
- read_screen   (read what is on the phone screen)
- look {question}   (take a camera photo and answer the question about it)
- screen {do, text}   (do = click | scroll_down | scroll_up | type | back | home | recents | notifications | quick_settings)
- none
When a message starts with [DATA ...], use that data to answer naturally with action none.
""".trimIndent()
    }

    fun ask(userText: String, apiKey: String, image: ByteArray? = null): JSONObject {
        history.add("user" to userText)
        try {
            val recent = history.takeLast(11) // odd count keeps the first turn a "user" turn
            val contents = JSONArray()
            recent.forEachIndexed { i, (role, text) ->
                val parts = JSONArray().put(JSONObject().put("text", text))
                if (image != null && i == recent.lastIndex) {
                    parts.put(JSONObject().put("inline_data", JSONObject()
                        .put("mime_type", "image/jpeg")
                        .put("data", Base64.encodeToString(image, Base64.NO_WRAP))))
                }
                contents.put(JSONObject().put("role", role).put("parts", parts))
            }
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts",
                    JSONArray().put(JSONObject().put("text", systemPrompt()))))
                .put("contents", contents)
                .put("generationConfig", JSONObject()
                    .put("responseMimeType", "application/json").put("temperature", 0.7))

            val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
            val (code, text) = Net.post(url, body.toString())
            if (code !in 200..299) {
                history.removeAt(history.lastIndex)
                return JSONObject().put("say", "Error $code. Check your API key.").put("action", "none")
            }
            val out = JSONObject(text).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            val result = try { JSONObject(out) } catch (e: Exception) {
                JSONObject().put("say", out).put("action", "none")
            }
            history.add("model" to out)
            return result
        } catch (e: Exception) {
            if (history.isNotEmpty() && history.last().first == "user") history.removeAt(history.lastIndex)
            throw e
        }
    }
}
