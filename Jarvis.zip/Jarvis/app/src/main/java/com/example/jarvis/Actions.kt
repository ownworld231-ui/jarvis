package com.example.jarvis

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.MediaStore
import org.json.JSONObject

/** Simple device actions via built-in Android intents (no paid services, minimal permissions). */
class Actions(private val ctx: Context, private val remember: (String) -> Unit) {

    private fun start(i: Intent) = ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    fun run(action: String, a: JSONObject) {
        when (action) {
            "open_app" -> openApp(a.optString("name"))
            "dial" -> start(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + a.optString("number"))))
            "sms" -> start(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + a.optString("number")))
                .putExtra("sms_body", a.optString("text")))
            "set_alarm" -> start(Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour"))
                .putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute"))
                .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Jarvis")))
            "set_timer" -> start(Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, a.optInt("seconds"))
                .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Jarvis"))
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            "flashlight" -> torch(a.optBoolean("on", true))
            "web_search" -> start(Intent(Intent.ACTION_VIEW,
                Uri.parse("https://www.google.com/search?q=" + Uri.encode(a.optString("query")))))
            "play_music" -> start(Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                .putExtra(android.app.SearchManager.QUERY, a.optString("query")))
            "navigate" -> start(Intent(Intent.ACTION_VIEW,
                Uri.parse("google.navigation:q=" + Uri.encode(a.optString("destination")))))
            "remember" -> remember(a.optString("fact"))
        }
    }

    private fun openApp(name: String) {
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(launcher, 0).firstOrNull {
            it.loadLabel(pm).toString().contains(name, ignoreCase = true)
        } ?: return
        pm.getLaunchIntentForPackage(match.activityInfo.packageName)?.let { start(it) }
    }

    private fun torch(on: Boolean) {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull() ?: return
        cm.setTorchMode(id, on)
    }
}
