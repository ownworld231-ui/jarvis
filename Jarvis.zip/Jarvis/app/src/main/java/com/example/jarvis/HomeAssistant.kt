package com.example.jarvis

import org.json.JSONArray
import org.json.JSONObject

/** Free smart-home control through your own Home Assistant server (REST API). */
object HomeAssistant {
    private val domains = setOf("light", "switch", "fan", "cover", "lock", "climate", "media_player", "scene", "script")

    fun entities(url: String, token: String): String {
        val arr = JSONArray(Net.get(url.trimEnd('/') + "/api/states", mapOf("Authorization" to "Bearer $token")))
        val sb = StringBuilder()
        var count = 0
        for (i in 0 until arr.length()) {
            if (count >= 80) break
            val o = arr.getJSONObject(i)
            val id = o.getString("entity_id")
            if (id.substringBefore('.') in domains) {
                val name = o.optJSONObject("attributes")?.optString("friendly_name") ?: ""
                sb.append(id).append(" (").append(name).append(")\n")
                count++
            }
        }
        return sb.toString()
    }

    fun call(url: String, token: String, domain: String, service: String, entityId: String): Boolean {
        val body = JSONObject().put("entity_id", entityId).toString()
        val (code, _) = Net.post(url.trimEnd('/') + "/api/services/$domain/$service", body,
            mapOf("Authorization" to "Bearer $token"))
        return code in 200..299
    }
}
