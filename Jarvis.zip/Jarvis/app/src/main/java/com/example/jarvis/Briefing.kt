package com.example.jarvis

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.CalendarContract
import android.util.Xml
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Daily briefing from free sources: Open-Meteo (weather), device calendar, BBC RSS (news). */
object Briefing {
    fun build(ctx: Context, city: String): String =
        "WEATHER: ${weather(city)}\nCALENDAR TODAY: ${calendar(ctx)}\nTOP NEWS: ${news()}"

    private fun weather(city: String): String {
        if (city.isBlank()) return "no city set in settings"
        return try {
            val g = JSONObject(Net.get("https://geocoding-api.open-meteo.com/v1/search?name=${Uri.encode(city)}&count=1"))
                .getJSONArray("results").getJSONObject(0)
            val lat = g.getDouble("latitude"); val lon = g.getDouble("longitude")
            val w = JSONObject(Net.get("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                "&current=temperature_2m&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
                "&timezone=auto&forecast_days=1"))
            val d = w.getJSONObject("daily")
            "${g.getString("name")}: now ${w.getJSONObject("current").getDouble("temperature_2m")}C, " +
                "high ${d.getJSONArray("temperature_2m_max").getDouble(0)}C, " +
                "low ${d.getJSONArray("temperature_2m_min").getDouble(0)}C, " +
                "rain chance ${d.getJSONArray("precipitation_probability_max").getInt(0)}%"
        } catch (e: Exception) { "unavailable" }
    }

    private fun calendar(ctx: Context): String {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED)
            return "calendar permission not granted"
        return try {
            val start = Calendar.getInstance()
            val end = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59)
            }
            val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
            ContentUris.appendId(b, start.timeInMillis)
            ContentUris.appendId(b, end.timeInMillis)
            val items = mutableListOf<String>()
            ctx.contentResolver.query(b.build(),
                arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN),
                null, null, "begin ASC")?.use { c ->
                val f = SimpleDateFormat("HH:mm", Locale.getDefault())
                while (c.moveToNext()) items.add(f.format(Date(c.getLong(1))) + " " + c.getString(0))
            }
            if (items.isEmpty()) "nothing scheduled" else items.joinToString("; ")
        } catch (e: Exception) { "unavailable" }
    }

    private fun news(): String {
        return try {
            val xml = Net.get("https://feeds.bbci.co.uk/news/rss.xml")
            val p = Xml.newPullParser()
            p.setInput(StringReader(xml))
            val titles = mutableListOf<String>()
            var inItem = false
            var e = p.eventType
            while (e != XmlPullParser.END_DOCUMENT && titles.size < 5) {
                if (e == XmlPullParser.START_TAG) {
                    if (p.name == "item") inItem = true
                    else if (inItem && p.name == "title") titles.add(p.nextText())
                }
                e = p.next()
            }
            titles.joinToString("; ")
        } catch (e: Exception) { "unavailable" }
    }
}
